from common import shared_logic

def func_a():
    return "A + " + shared_logic()

